<?php

$english = array(
    'menu:site:header:default' => 'Menu',
    'menu:site:header:more' => 'More',
);

add_translation("en", $english);