<?php

$german = array(
    'menu:site:header:default' => 'Navigation',
    'menu:site:header:more' => 'Mehr',
);

add_translation("de", $german);