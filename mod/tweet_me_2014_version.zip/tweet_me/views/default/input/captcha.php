<?php
/**
 * This view provides a hook for third parties to provide a CAPTCHA.
 *
 * @package Elgg
 * @subpackage Core
 */
?>