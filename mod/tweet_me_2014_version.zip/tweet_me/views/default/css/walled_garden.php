<?php
/**
 * Walled garden CSS
 */

$url = elgg_get_site_url();

?>