<?php
core_version::activate();
