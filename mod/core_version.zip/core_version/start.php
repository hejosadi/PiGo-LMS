<?php
elgg_register_event_handler('init', 'system', array('core_version', 'init'));
