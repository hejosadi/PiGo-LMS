<?php
/***************************************************
 * SW Social Web                                   *
 * Copyrights (c) 2010-2020. SW Social Web         *
 * All rights reserved                             *
 ***************************************************
 */

?>
<div class="image_view">
  <?php echo $vars['entity']->getThumb()?>
<!--  ?php echo $vars['url'].'mod/izap-contest/content.php?id='.$vars['quiz_entity']->guid.'&size=medium'?>" />-->
</div>
<div class="options_view">
  <?php
  $quiz_metadata_array = unserialize($vars['entity']->quiz_metadata);
  if(isset($quiz_metadata_array[$_SESSION['user']->username])) {
    echo elgg_view("input/radio", array("name" => "quiz[correct_option]",  "disabled"=> 1, 'value'=>$quiz_metadata_array[$_SESSION['user']->username]['reply'], "options" => $vars['entity']->get_options()));
  }else {
    echo elgg_view("input/radio", array("name" => "quiz[correct_option]",  "options" => $vars['entity']->get_options(), 'value' => $vars['entity']->getCorrectAnswer()));
  }
  ?>
  <div class="clearfloat"></div>
</div>