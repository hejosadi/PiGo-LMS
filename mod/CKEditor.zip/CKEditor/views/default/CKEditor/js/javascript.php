<script type="text/javascript" src="<?php echo $vars['url']; ?>mod/CKEditor/ckeditor/ckeditor.js">
    

    $(document).ready(function(){
        window.saveDraft = function() {  };

        
    });
    </script>