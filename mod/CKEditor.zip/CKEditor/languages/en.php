<?php

$english = array( 'ckeditor:admin_title' => "Configure CKEditor");	
add_translation("en",$english);

?>
