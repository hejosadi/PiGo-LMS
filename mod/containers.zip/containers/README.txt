= containers for elgg 1.8 =
adds a dropdown selctor to the edit/save forms of common elgg mods such as blogs, pages, files, videolist and tidypics to allow the container to be set for the current item.
available containers are the user profile of the current user and the groups to which the user is associated (a member). this allows all items to be added from the same 'add new' page and also allows items to be moved between groups. 

supports blog_tools, pages_tools and file_tools plugins.

== 1. Features ==
adds container field to edit pages
adds output label to show which group the entity is contained by


version >= 0.5.2 of this plugin is designed for blog_tools version >= 2.5. if you are using blog_tools with a version lower than 2.5 then you may need to use 0.5.1 of this plugin. 