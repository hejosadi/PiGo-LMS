<?php
/**
 * Containers English language file
 */

$english = array(
	'container' => 'Container',
	'container:in-group' => 'Part of group',
	);

add_translation("en", $english);