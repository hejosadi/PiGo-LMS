<?php
/**
 * Categories CSS extender
 *
 * @package Categories
 */
?>

.elgg-output-container{
    margin: 9px 0 !important;
    font-size: 85%;
    line-height: 1.2em;
    font-style: italic;
}
